import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;

public class MorseCodeConverter {
	
	private static MorseCodeTree tree = new MorseCodeTree();

	/**
	 * Constructor
	 */
	public MorseCodeConverter() {
		
	}
	
	/**
	 * returns a string with all the data in the tree in LNR order 
	 * with an space in between them. Uses the toArrayList method in 
	 * MorseCodeTree It should return the data in this order:
	 * "h s v i f u e l r a p w j b d x n c k y t z g q m o"
	 * @return the data in the tree in LNR order separated by a space.
	 */
	public static String printTree() {
		ArrayList<String> morseTree = tree.toArrayList();
	    StringBuilder sb = new StringBuilder();

	    for (String letters : morseTree) {
	      sb.append(letters).append(" ");
	    }
	    return sb.toString().trim();
	}
	
	
	/**
	 * Converts Morse code into English.
	 * Example:
	 * code = ".... . .-.. .-.. --- / .-- --- .-. .-.. -.."
	 * string returned = "Hello World"
	 * @param code - the morse code
	 * @return the English translation
	 */
	public static String convertToEnglish(String code) {
		String[] letter;
	    String[] word = code.split(" / ");
	    StringBuilder english = new StringBuilder();

	    for(int i = 0; i < word.length; i++) {
	      letter = word[i].split(" ");
	      for(int j = 0; j < letter.length; j++) {
	        english.append(tree.fetch(letter[j]));
	      }
	      english.append(" ");
	    }
	    return english.toString().trim();
	}
	
	
	/**
	 * Converts a file of Morse code into English 
	 * Example:
	 * a file that contains ".... . .-.. .-.. --- / .-- --- .-. .-.. -.."
	 * string returned = "Hello World"
	 * @param codeFile - name of the File that contains Morse Code
	 * @return the English translation of the file
	 * @throws FileNotFoundException
	 */	
	public static String convertToEnglish(File codeFile) throws FileNotFoundException {		 		
		
		StringBuilder sb = new StringBuilder();		    
		InputStream is = new FileInputStream(codeFile);	   
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		   
		br.lines().forEach(s -> sb.append(convertToEnglish(s)).append("\n"));		    
		try {		      
			br.close();		    
		} catch (IOException e) {		      
			e.printStackTrace();		   
		}		    
		return sb.toString().trim();
	
	}

}
