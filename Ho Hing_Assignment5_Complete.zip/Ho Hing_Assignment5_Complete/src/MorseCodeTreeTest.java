import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MorseCodeTreeTest {

	MorseCodeTree tree = new MorseCodeTree();
	
	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
		tree = null;
	}

	@Test
	void testGetRoot() {
		String root;
		root = tree.getRoot().getData();
		assertEquals("", root);
	}

	@Test
	void testSetRoot() {
		String newRoot;

		assertEquals("", tree.getRoot().getData());

		TreeNode<String> name = new TreeNode <String> ("Nabeel");
		tree.setRoot(name);
		newRoot = tree.getRoot().getData();

		assertEquals("Nabeel", newRoot);
	}

	@Test
	void testInsert() {
		tree.insert(".----", "1");
		String letterFetched = tree.fetch(".----");
		assertEquals("1", letterFetched);		
	}

	@Test
	void testFetch() {
		String letterFetched;
		String letterFetched2;
		
		letterFetched = tree.fetch("-.");
		assertEquals("n", letterFetched);

		letterFetched2 = tree.fetch("--.-");
		assertEquals("q", letterFetched2);
	}

	@Test
	void testToArrayList() {
		ArrayList<String> list = new ArrayList<String>();
		list = tree.toArrayList();
		
		assertEquals("h", list.get(0));
		assertEquals("s", list.get(1));
		assertEquals("v", list.get(2));
		assertEquals("i", list.get(3));
		assertEquals("f", list.get(4));
		assertEquals("u", list.get(5));
		assertEquals("e", list.get(6));
		assertEquals("l", list.get(7));
		assertEquals("r", list.get(8));
		assertEquals("a", list.get(9));
		assertEquals("p", list.get(10));
		assertEquals("w", list.get(11));
		assertEquals("j", list.get(12));
		assertEquals("", list.get(13));
		assertEquals("b", list.get(14));
		assertEquals("d", list.get(15));
		assertEquals("x", list.get(16));
		assertEquals("n", list.get(17));
		assertEquals("c", list.get(18));
		assertEquals("k", list.get(19));
		assertEquals("y", list.get(20));
		assertEquals("t", list.get(21));
		assertEquals("z", list.get(22));
		assertEquals("g", list.get(23));
		assertEquals("q", list.get(24));
		assertEquals("m", list.get(25));
		assertEquals("o", list.get(26));
	}

}
